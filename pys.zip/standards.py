# Modular 
# Maintainable 
# The zen of python by Tim Peters
import this